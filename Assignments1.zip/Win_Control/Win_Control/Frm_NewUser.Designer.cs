﻿namespace Win_Control
{
    partial class Frm_Newuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_login = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customergender = new System.Windows.Forms.Label();
            this.txt_login = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.cmb_customercity = new System.Windows.Forms.ComboBox();
            this.rb_male = new System.Windows.Forms.RadioButton();
            this.rb_female = new System.Windows.Forms.RadioButton();
            this.but_newuser = new System.Windows.Forms.Button();
            this.but_close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_login
            // 
            this.lbl_login.AutoSize = true;
            this.lbl_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_login.Location = new System.Drawing.Point(46, 30);
            this.lbl_login.Name = "lbl_login";
            this.lbl_login.Size = new System.Drawing.Size(95, 25);
            this.lbl_login.TabIndex = 0;
            this.lbl_login.Text = "Login ID :";
            this.lbl_login.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(49, 96);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(109, 25);
            this.lbl_password.TabIndex = 1;
            this.lbl_password.Text = "Password :";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(49, 163);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(165, 25);
            this.lbl_customername.TabIndex = 2;
            this.lbl_customername.Text = "Customer Name :";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customercity.Location = new System.Drawing.Point(49, 232);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(147, 25);
            this.lbl_customercity.TabIndex = 3;
            this.lbl_customercity.Text = "Customer City :";
            // 
            // lbl_customergender
            // 
            this.lbl_customergender.AutoSize = true;
            this.lbl_customergender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customergender.Location = new System.Drawing.Point(52, 297);
            this.lbl_customergender.Name = "lbl_customergender";
            this.lbl_customergender.Size = new System.Drawing.Size(178, 25);
            this.lbl_customergender.TabIndex = 4;
            this.lbl_customergender.Text = "Customer Gender :";
            // 
            // txt_login
            // 
            this.txt_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_login.Location = new System.Drawing.Point(298, 25);
            this.txt_login.Name = "txt_login";
            this.txt_login.Size = new System.Drawing.Size(278, 30);
            this.txt_login.TabIndex = 5;
            // 
            // txt_password
            // 
            this.txt_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.Location = new System.Drawing.Point(298, 91);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(278, 30);
            this.txt_password.TabIndex = 6;
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(298, 158);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(278, 30);
            this.txt_customername.TabIndex = 7;
            // 
            // cmb_customercity
            // 
            this.cmb_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_customercity.FormattingEnabled = true;
            this.cmb_customercity.Location = new System.Drawing.Point(298, 224);
            this.cmb_customercity.Name = "cmb_customercity";
            this.cmb_customercity.Size = new System.Drawing.Size(278, 33);
            this.cmb_customercity.TabIndex = 8;
            // 
            // rb_male
            // 
            this.rb_male.AutoSize = true;
            this.rb_male.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_male.Location = new System.Drawing.Point(298, 297);
            this.rb_male.Name = "rb_male";
            this.rb_male.Size = new System.Drawing.Size(76, 29);
            this.rb_male.TabIndex = 9;
            this.rb_male.TabStop = true;
            this.rb_male.Text = "Male";
            this.rb_male.UseVisualStyleBackColor = true;
            // 
            // rb_female
            // 
            this.rb_female.AutoSize = true;
            this.rb_female.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_female.Location = new System.Drawing.Point(478, 297);
            this.rb_female.Name = "rb_female";
            this.rb_female.Size = new System.Drawing.Size(98, 29);
            this.rb_female.TabIndex = 10;
            this.rb_female.TabStop = true;
            this.rb_female.Text = "Female";
            this.rb_female.UseVisualStyleBackColor = true;
            // 
            // but_newuser
            // 
            this.but_newuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_newuser.Location = new System.Drawing.Point(108, 394);
            this.but_newuser.Name = "but_newuser";
            this.but_newuser.Size = new System.Drawing.Size(107, 42);
            this.but_newuser.TabIndex = 11;
            this.but_newuser.Text = "New User";
            this.but_newuser.UseVisualStyleBackColor = true;
            // 
            // but_close
            // 
            this.but_close.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_close.Location = new System.Drawing.Point(469, 393);
            this.but_close.Name = "but_close";
            this.but_close.Size = new System.Drawing.Size(107, 42);
            this.but_close.TabIndex = 12;
            this.but_close.Text = "Close";
            this.but_close.UseVisualStyleBackColor = true;
            // 
            // Frm_Newuser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(784, 474);
            this.Controls.Add(this.but_close);
            this.Controls.Add(this.but_newuser);
            this.Controls.Add(this.rb_female);
            this.Controls.Add(this.rb_male);
            this.Controls.Add(this.cmb_customercity);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_login);
            this.Controls.Add(this.lbl_customergender);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_login);
            this.Name = "Frm_Newuser";
            this.Text = "Frm_Newuser";
            this.Load += new System.EventHandler(this.Frm_Newuser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customergender;
        private System.Windows.Forms.TextBox txt_login;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.ComboBox cmb_customercity;
        private System.Windows.Forms.RadioButton rb_male;
        private System.Windows.Forms.RadioButton rb_female;
        private System.Windows.Forms.Button but_newuser;
        private System.Windows.Forms.Button but_close;
    }
}
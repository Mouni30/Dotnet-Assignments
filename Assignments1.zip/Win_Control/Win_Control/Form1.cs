﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Control
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            if(txt_login.Text==string.Empty)
            {
                MessageBox.Show("Enter Login ID :");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("Enter Password :");
            }
            else
            {
                int loginid = Convert.ToInt32(txt_login.Text);
                string password = txt_password.Text;
                if(loginid==1001 && password=="pass@123")
                {
                    MessageBox.Show("Valid User");
                    Frm_Home obj = new Frm_Home();
                    obj.Show();//open the form
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }
            }
        }

        private void bt_use_Click(object sender, EventArgs e)
        {
            Frm_Newuser obj = new Frm_Newuser();
            obj.Show();
        }
    }
}

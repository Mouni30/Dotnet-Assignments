﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Control
{
    public partial class Frm_Newuser : Form
    {
        public Frm_Newuser()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbl_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lbl_newuser_Click(object sender, EventArgs e)
        {
            if(txt_login.Text==string.Empty)
            {
                MessageBox.Show("Enter Login ID : ");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("Enter Password :");
            }
            else if(txt_customername.Text==string.Empty)
            {
                MessageBox.Show("Enter Customer Name :");
            }
            else if(cmb_customercity.Text==string.Empty)
            {
                MessageBox.Show("Select City");
            }
            else if(rb_male.Checked==false && rb_female.Checked==false)
            {
                MessageBox.Show("Select Gender");
            }
            else
            {
                int loginid = Convert.ToInt32(txt_login.Text);
                string password = txt_password.Text;
                string customername = txt_customername.Text;
                string customercity = cmb_customercity.Text;
                string customergender = string.Empty;
                if(rb_male.Checked)
                {
                    customergender = "Male";
                }
                else
                {
                    customergender = "Female";
                }
                MessageBox.Show("Customer Created");
            }        
        }

        private void Frm_Newuser_Load(object sender, EventArgs e)
        {
            cmb_customercity.Items.Add("BGL");
            cmb_customercity.Items.Add("Pune");
            cmb_customercity.Items.Add("HYD");
            cmb_customercity.Items.Add("Chennai");
            cmb_customercity.Items.Add("AP");
        }
    }
}

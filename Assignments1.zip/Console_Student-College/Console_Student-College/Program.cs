﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class Program
    {
        static void Main(string[] args)
        {
            College pathfront = new College(1001, "Pathfront,BGL");
            Console.WriteLine(pathfront.PCollegeId + " " + pathfront.PCollegeName);
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1-Add,2-Find,3-Remove,4-Show,5-Request Leave,6-Exit");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter Student Name :");
                            string StudentName = Console.ReadLine();
                            Console.WriteLine("Enter Student City :");
                            string StudentCity = Console.ReadLine();
                            Student obj = new Student(StudentName, StudentCity);
                            pathfront.AddStudent(obj);
                            Console.WriteLine("Your Student Id :" + obj.PStudentId);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter Student Id :");
                            int ID = Convert.ToInt32(Console.ReadLine());
                            Student obj = pathfront.FindStudent(ID);
                            if(obj!=null)
                            {
                                Console.WriteLine("Student Details");
                                Console.WriteLine(obj.PStudentId + " " + obj.PStudentName + " " + obj.PStudentCity);
                            }
                            else
                            {
                                Console.WriteLine("Student Not Found");
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter Student Id :");
                            int ID = Convert.ToInt32(Console.ReadLine());
                            bool status = pathfront.RemoveStudent(ID);
                            if(status==true)
                            {
                                Console.WriteLine("Student Removed");
                            }
                            else
                            {
                                Console.WriteLine("Student Not Found");
                            }
                            break;
                        }
                    case 4:
                        {
                            pathfront.ShowAll();
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter Student ID :");
                            int ID = Convert.ToInt32(Console.ReadLine());
                            Student obj = pathfront.FindStudent(ID);
                            if(obj!=null)
                            {
                                Console.WriteLine("Enter Reason :");
                                string Reason = Console.ReadLine();
                                obj.LeaveRequest(Reason);
                            }
                            else
                            {
                                Console.WriteLine("Wrong Student ID");
                            }
                            break;
                        }
                    case 6:
                        {
                            flag = false;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("You have Entered a Wrong Option");
                            break;
                        }
                }
            }
            Console.ReadLine();
        }
    }
}

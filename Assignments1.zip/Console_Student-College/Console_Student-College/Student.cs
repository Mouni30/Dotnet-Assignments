﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class Student
    {
        private int StudentId;
        private string StudentName;
        private string StudentCity;
        public static int count = 1000;
        public Student(string StudentName,string StudentCity)
        {
            this.StudentId = ++Student.count;
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;
        }
        public int PStudentId
        {
            get
            {
                return this.StudentId;
            }
        }
        public string PStudentName
        {
            get
            {
                return this.StudentName;
            }
        }
        public string PStudentCity
        {
            get
            {
                return this.StudentCity;
            }
            set
            {
                this.StudentCity = value;
            }
        }
        public void LeaveRequest(string Reason)
        {
            Console.WriteLine("Leave Request : StudentID : " + this.StudentId + ",Reason : " + Reason);
        }
    }
}

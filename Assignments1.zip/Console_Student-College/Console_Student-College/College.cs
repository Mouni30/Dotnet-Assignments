﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class College
    {
        private int CollegeId;
        private string CollegeName;
        private List<Student> studentlist = new List<Student>();
        public College(int CollegeId,string CollegeName)
        {
            this.CollegeId = CollegeId;
            this.CollegeName = CollegeName;
        }
        public int PCollegeId
        {
            get
            {
                return this.CollegeId;
            }
        }
        public string PCollegeName
        {
            get
            {
                return this.CollegeName;
            }
        }
        public void AddStudent(Student obj)
        {
            studentlist.Add(obj);
            Console.WriteLine("Student Added Successfully....");
        }
        public bool RemoveStudent(int ID)
        {
            foreach(Student s in this.studentlist)
            {
                if(s.PStudentId==ID)
                {
                    this.studentlist.Remove(s);
                    return true;
                }
            }
            return false;
        }
        public Student FindStudent(int ID)
        {
            foreach(Student s in this.studentlist)
            {
                if(s.PStudentId==ID)
                {
                    return s;
                }
            }
            return null;
        }
        public void ShowAll()
        {
            foreach(Student s in this.studentlist)
            {
                Console.WriteLine(s.PStudentId + "  " + s.PStudentName);
            }
        }
    }
}

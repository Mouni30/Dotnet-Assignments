﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collections
{
    class Test
    {
        public T GetData<T>(T para)
        {
            return para;
        }
    }
}

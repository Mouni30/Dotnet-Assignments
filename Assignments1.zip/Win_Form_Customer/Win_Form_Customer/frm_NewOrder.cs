﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Form_Customer
{
    public partial class frm_NewOrder : Form
    {
        public frm_NewOrder()
        {
            InitializeComponent();
        }
    }
}

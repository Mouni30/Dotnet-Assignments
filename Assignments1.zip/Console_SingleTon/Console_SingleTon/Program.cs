﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_SingleTon
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager m1 = Manager.GetManager();
            Manager m2 = Manager.GetManager();
            if(m1==m2)
            {
                Console.WriteLine("SingleTon");
            }
            else
            {
                Console.WriteLine("Not SingleTon");
            }
            Console.ReadLine();
        }
    }
}

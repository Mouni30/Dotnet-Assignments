﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows_Form_CustomerLogin
{
    class Customer
    {
        private string CustomerEmail;
        private string CustomerName;
        private string CustomerCity;
        private string CustomerGender;
        public Customer(string CustomerEmail,string CustomerName,string CustomerCity,string CustomerGender)
        {
            this.CustomerEmail = CustomerEmail;
            this.CustomerName = CustomerName;
            this.CustomerCity = CustomerCity;
            this.CustomerGender = CustomerGender;
        }
        public string PCustomerEmail
        {
            get
            {
                return this.CustomerEmail;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PCustomerCity
        {
            get
            {
                return this.CustomerCity;
            }
        }
        public string PCustomerGender
        {
            get
            {
                return this.CustomerGender;
            }
        }
    }
}

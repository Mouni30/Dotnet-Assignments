﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Form_CustomerLogin
{
    public partial class frm_NewOrder : Form
    {
        public frm_NewOrder()
        {
            InitializeComponent();
        }

        private void bt_neworder_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter Customer ID :");
            }
            else if (txt_itemname.Text == string.Empty)
            {
                MessageBox.Show("Enter Item Name :");
            }
            else if (txt_itemprice.Text == string.Empty)
            {
                MessageBox.Show("Enter Item Price :");
            }
            else if (txt_itemquantity.Text == string.Empty)
            {
                MessageBox.Show("Enter Item Quantity :");
            }
            else
            {
                string customerid =txt_customerid.Text;
                string itemname = txt_itemname.Text;
                int itemprice = Convert.ToInt32(txt_itemprice.Text);
                int itemquantity = Convert.ToInt32(txt_itemquantity.Text);
                Order obj = new Order(customerid,itemname, itemprice, itemquantity);
                MessageBox.Show(obj.POrderID+" "+obj.PCustomerEmailID+" "+ obj.PItemName+" "+obj.PItemPrice+" "+obj.PItemQuantity);
                int value=obj.GetOrderValue();
                MessageBox.Show("Order Amount :"+value);

            }
        }

        private void bt_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

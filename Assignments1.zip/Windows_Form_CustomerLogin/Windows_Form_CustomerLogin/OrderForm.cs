﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows_Form_CustomerLogin
{
    class Order
    {
        private int OrderID;
        private string CustomerEmailID;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;
        public static int count = 1000;
        public Order(string CustomerEmailID,string ItemName,int ItemPrice,int ItemQuantity)
        {
            this.OrderID = ++Order.count;
            this.CustomerEmailID = CustomerEmailID;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;
        }
        public int POrderID
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerEmailID
        {
            get
            {
                return this.CustomerEmailID;
            }
        }
        public string PItemName
        {
            get
            {
                return this.ItemName;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public int PItemQuantity
        {
            get
            {
                return this.ItemQuantity;
            }
        }
        public int GetOrderValue()
        {
            return this.ItemPrice * this.ItemQuantity;
        }
    }
}
